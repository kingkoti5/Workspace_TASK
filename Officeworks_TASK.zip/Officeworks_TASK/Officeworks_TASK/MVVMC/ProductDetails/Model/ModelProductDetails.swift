//
//  ModelProductDetails.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 21/11/26.
//


import Foundation

// MARK: - ProductDetails
struct ProductDetails: Codable {
    let id: Int
    let title: String
    let price: Double
    let description: String
    let category: String
    let image: String
    let rating: ProductRating

    enum CodingKeys: String, CodingKey {
        case id = "id"
        case title = "title"
        case price = "price"
        case description = "description"
        case category = "category"
        case image = "image"
        case rating = "rating"
    }
}

// MARK: - Rating
struct ProductRating: Codable {
    let rate: Double
    let count: Int

    enum CodingKeys: String, CodingKey {
        case rate = "rate"
        case count = "count"
    }
}
