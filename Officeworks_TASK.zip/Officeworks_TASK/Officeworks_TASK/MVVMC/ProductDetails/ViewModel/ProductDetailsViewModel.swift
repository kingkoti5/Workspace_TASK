//
//  ProductDetailsViewModel.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 21/11/26.
//

import Foundation
import Combine

class ProductDetailsViewModel :ObservableObject {
    
    
    @Published var productDetailsData: ProductDetails? = nil



   

    let productDetails:productDetailsRepojarity
    
    init(productDetails: productDetailsRepojarity) {
        self.productDetails = productDetails
    }
    
    
    func productApicalling(id:Int) async throws {
        
        
        do {
            let productDetaild = try await productDetails.priductApicalling(id: id)
            
            productDetailsData = productDetaild
            print("%%%%%%%%%%%%productDetaild:::",productDetaild)
            
            
            
        } catch {
            
            
        }
        
    }
    
    
    
    
    
}
