//
//  ProductDetailsRepojarity.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 21/11/26.
//

import Foundation


class productDetailsRepojarity {
    
    var productServer:ServerApicalling
    
    
    init(productServer: ServerApicalling) {
        self.productServer = productServer
    }
    
    
    
    func priductApicalling(id:Int) async throws  -> ProductDetails {
        
        
       
        
        return try await productServer.apiCalling(url: Apiendpoints.productDetails(id: id).url, httpMethod: .GET, modelData: ProductDetails.self)
        
    }
}
