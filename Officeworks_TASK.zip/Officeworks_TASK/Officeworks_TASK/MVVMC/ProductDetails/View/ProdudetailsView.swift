//
//  ProdudetailsView.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 21/11/26.
//

import SwiftUI


import SwiftUI

// MARK: - Product Variant Model

struct ProductVariant: Identifiable {
    let id: String
    let name: String
    let imageName: String
    let color: Color
}

// MARK: - Product Details View

struct ProdudetailsView: View {

    // MARK: State

    @StateObject var viewModel:ProductDetailsViewModel
        var productid:Int
        @EnvironmentObject var coordinator: AppCoordinator
    @State private var quantity = 1
    @State private var selectedVariantID = "beige"

    // MARK: Product Variants

    private let variants: [ProductVariant] = [
        ProductVariant(
            id: "green",
            name: "Green",
            imageName: "headphone_green",
            color: Color(hex: "#66866D")
        ),
        ProductVariant(
            id: "pink",
            name: "Pink",
            imageName: "headphone_pink",
            color: Color(hex: "#E8799D")
        ),
        ProductVariant(
            id: "blue",
            name: "Blue",
            imageName: "headphone_blue",
            color: Color(hex: "#91B9D0")
        ),
        ProductVariant(
            id: "beige",
            name: "Beige",
            imageName: "headphone_beige",
            color: Color(hex: "#D0C9BC")
        )
    ]

    private var selectedVariant: ProductVariant {
        variants.first(where: {
            $0.id == selectedVariantID
        }) ?? variants[3]
    }

    // MARK: Body

    var body: some View {

        ScrollView(showsIndicators: false) {

            VStack(alignment: .leading, spacing: 20) {

                // Product Image
              
                
                
                if let productImage = viewModel.productDetailsData {
                    ReusebuleImageDetails(productDetails: productImage)

                }
                

                // Product Information
                if let productInfermation = viewModel.productDetailsData {
                    productInformationSection(productDetails: productInfermation)

                }

                // Price and Quantity
                priceAndQuantitySection

                // Color Selection
                colorSelectionSection

               
            }
            .padding(.bottom, 20)
        }
        .background(Color.white)
        .safeAreaInset(edge: .bottom, spacing: 0) {
            bottomCartButton
        }
        .ignoresSafeArea(edges: .top)
        
        .task {
            do {
                
                try await viewModel.productApicalling(id: productid)
                
            } catch {
                
            }
            
            
        }
    }

    // MARK: Price and Quantity

    private var priceAndQuantitySection: some View {

        HStack {

            HStack(alignment: .firstTextBaseline, spacing: 5) {

                Text("$\(viewModel.productDetailsData?.price ?? 0)")
                    .font(.system(size: 28, weight: .medium))
                    .foregroundStyle(.black)

                Text("USD")
                    .font(.system(size: 15))
                    .foregroundStyle(.gray)
            }

            Spacer()

            HStack(spacing: 16) {

                quantityButton(
                    icon: "minus",
                    action: {
                        if quantity > 1 {
                            quantity -= 1
                        }
                    }
                )

                Text("\(quantity)")
                    .font(.system(size: 17, weight: .medium))
                    .foregroundStyle(.black)
                    .frame(minWidth: 15)

                quantityButton(
                    icon: "plus",
                    action: {
                        quantity += 1
                    }
                )
            }
        }
        .padding(.horizontal, 25)
    }

    // MARK: Quantity Button

    private func quantityButton(
        icon: String,
        action: @escaping () -> Void
    ) -> some View {

        Button(action: action) {

            Image(systemName: icon)
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(Color.black)
                .frame(width: 43, height: 43)
                .background(Color.white)
                .clipShape(RoundedRectangle(cornerRadius: 13))
                .shadow(
                    color: .black.opacity(0.10),
                    radius: 6,
                    x: 0,
                    y: 3
                )
        }
        .buttonStyle(.plain)
    }

    // MARK: Color Selection

    private var colorSelectionSection: some View {

        VStack(alignment: .leading, spacing: 12) {

            HStack(spacing: 10) {

                ForEach(variants) { variant in

                    Button {

                        selectedVariantID = variant.id

                    } label: {

                        ZStack {

                            RoundedRectangle(cornerRadius: 25)
                                .fill(Color(hex: "#E9E5DC"))

                            Image(variant.imageName)
                                .resizable()
                                .scaledToFit()
                                .padding(5)
                        }
                        .frame(maxWidth: .infinity)
                        .frame(height: 115)
                        .clipShape(RoundedRectangle(cornerRadius: 25))
                        .overlay {

                            RoundedRectangle(cornerRadius: 25)
                                .stroke(
                                    selectedVariantID == variant.id
                                    ? Color(hex: "#9DAF92")
                                    : Color.clear,
                                    lineWidth: 2
                                )
                        }
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel(variant.name)
                    .accessibilityAddTraits(
                        selectedVariantID == variant.id
                        ? .isSelected : []
                    )
                }
            }

            Text("Selected Color: \(selectedVariant.name)")
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(.secondary)
        }
        .padding(.horizontal, 25)
    }



    // MARK: Bottom Cart Button

    private var bottomCartButton: some View {

        VStack(spacing: 0) {

            Button {

                print(
                    "Added \(quantity) \(selectedVariant.name) headphones to cart"
                )

            } label: {

                Text("Add to Cart")
                    .font(.system(size: 17, weight: .medium))
                    .foregroundStyle(Color(hex: "#3F493D"))
                    .frame(maxWidth: .infinity)
                    .frame(height: 55)
                    .background(Color(hex: "#CBD5BC"))
                    .clipShape(Capsule())
                    .overlay {

                        Capsule()
                            .stroke(
                                Color(hex: "#91A58A"),
                                lineWidth: 2
                            )
                            .padding(3)
                    }
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 25)
            .padding(.top, 12)
            .padding(.bottom, 8)
            
            
            Button {

                coordinator.push(routh: .Enquire)

               

            } label: {

                Text("Enquire")
                    .font(.system(size: 17, weight: .medium))
                    .foregroundStyle(Color(hex: "#3F493D"))
                    .frame(maxWidth: .infinity)
                    .frame(height: 55)
                    .background(Color(hex: "#CBD5BC"))
                    .clipShape(Capsule())
                    .overlay {

                        Capsule()
                            .stroke(
                                Color(hex: "#91A58A"),
                                lineWidth: 2
                            )
                            .padding(3)
                    }
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 25)
            .padding(.top, 12)
            .padding(.bottom, 8)
        }
        .background(Color.white)
    }
}

// MARK: - Hex Color Extension

extension Color {

    init(hex: String) {

        let hex = hex.trimmingCharacters(
            in: CharacterSet.alphanumerics.inverted
        )

        let value = UInt64(hex, radix: 16) ?? 0

        self.init(
            .sRGB,
            red: Double((value >> 16) & 0xFF) / 255,
            green: Double((value >> 8) & 0xFF) / 255,
            blue: Double(value & 0xFF) / 255,
            opacity: 1
        )
    }
}
