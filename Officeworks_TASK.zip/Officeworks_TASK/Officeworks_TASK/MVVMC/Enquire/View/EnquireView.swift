//
//  EnquireView.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 21/11/26.
//

import SwiftUI




import SwiftUI

struct EnquireView: View {

    @StateObject private var viewModel = InquiryViewModel()
    @EnvironmentObject var coordinator: AppCoordinator

    var body: some View {

        VStack(spacing: 0) {

            // MARK: - Header

            HStack(spacing: 14) {

                
                Text("Add Inquiry")
                    .font(.system(size: 19, weight: .semibold))
                    .foregroundColor(.white)

                Spacer()
            }
            .padding(.horizontal, 20)
            .frame(height: 60)
            .background(AppColors.primaryBrown)

            // MARK: - Form

            ScrollView(showsIndicators: false) {

                VStack(spacing: 20) {

                    CustomTextField(
                        title: "Name",
                        placeholder: "Enter your name",
                        text: $viewModel.inquiry.name,
                        errorMessage: viewModel.nameError
                    )
                    .onChange(of: viewModel.inquiry.name) { _ in
                        viewModel.validateIfNeeded()
                    }

                    CustomTextField(
                        title: "Mobile Number",
                        placeholder: "Enter mobile number",
                        text: $viewModel.inquiry.mobileNumber,
                        keyboardType: .numberPad,
                        capitalization: .never,
                        errorMessage: viewModel.mobileError
                    )
                    .onChange(of: viewModel.inquiry.mobileNumber) { value in
                        viewModel.updateMobileNumber(value)
                    }

                    CustomTextField(
                        title: "Email Id",
                        placeholder: "Enter email address",
                        text: $viewModel.inquiry.email,
                        isRequired: false,
                        keyboardType: .emailAddress,
                        capitalization: .never,
                        errorMessage: viewModel.emailError
                    )
                    .onChange(of: viewModel.inquiry.email) { _ in
                        viewModel.validateIfNeeded()
                    }

                    CustomTextField(
                        title: "State",
                        placeholder: "Enter state",
                        text: $viewModel.inquiry.state,
                        errorMessage: viewModel.stateError
                    )
                    .onChange(of: viewModel.inquiry.state) { _ in
                        viewModel.validateIfNeeded()
                    }

                    CustomTextField(
                        title: "City",
                        placeholder: "Enter city",
                        text: $viewModel.inquiry.city,
                        errorMessage: viewModel.cityError
                    )
                    .onChange(of: viewModel.inquiry.city) { _ in
                        viewModel.validateIfNeeded()
                    }

                    // MARK: - Submit Button

                    PrimaryButton(title: "Submit") {
                        //viewModel.submitInquiry()
                        
                        
                        coordinator.Pop()
                    }
                    .padding(.top, 18)

                }
                .padding(.horizontal, 20)
                .padding(.top, 24)
                .padding(.bottom, 30)
            }

            Spacer(minLength: 0)
        }
        .background(Color.white)
        .ignoresSafeArea(edges: .bottom)
        .alert("Success", isPresented: $viewModel.showSuccessAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text("Your inquiry has been submitted successfully.")
        }
    }
}

#Preview {
    EnquireView()
}
