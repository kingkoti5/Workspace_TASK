//
//  ModelEnquire.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 21/11/26.
//

import Foundation

struct InquiryModel {
    var name: String = ""
    var mobileNumber: String = ""
    var email: String = ""
    var state: String = ""
    var city: String = ""
}



import SwiftUI

enum AppColors {

    static let primaryBrown = Color(
        red: 77 / 255,
        green: 36 / 255,
        blue: 27 / 255
    )

    static let textColor = Color(
        red: 45 / 255,
        green: 45 / 255,
        blue: 45 / 255
    )

    static let fieldBackground = Color(
        red: 243 / 255,
        green: 244 / 255,
        blue: 246 / 255
    )

    static let errorColor = Color.red
}
