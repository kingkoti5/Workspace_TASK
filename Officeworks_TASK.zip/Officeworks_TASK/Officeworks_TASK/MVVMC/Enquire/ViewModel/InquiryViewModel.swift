//
//  InquiryViewModel.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 21/11/26.
//

import Foundation

import Combine

@MainActor
final class InquiryViewModel: ObservableObject {

    @Published var inquiry = InquiryModel()

    @Published var nameError: String?
    @Published var mobileError: String?
    @Published var emailError: String?
    @Published var stateError: String?
    @Published var cityError: String?

    @Published var showSuccessAlert = false

    private var hasAttemptedSubmit = false

    // MARK: - Mobile Number Formatting

    func updateMobileNumber(_ value: String) {
        let filtered = String(value.filter { $0.isNumber }.prefix(10))

        if inquiry.mobileNumber != filtered {
            inquiry.mobileNumber = filtered
        }

        validateIfNeeded()
    }

    // MARK: - Validation

    private func validateFields() {

        let name = inquiry.name.trimmingCharacters(in: .whitespacesAndNewlines)
        let mobile = inquiry.mobileNumber
        let email = inquiry.email.trimmingCharacters(in: .whitespacesAndNewlines)
        let state = inquiry.state.trimmingCharacters(in: .whitespacesAndNewlines)
        let city = inquiry.city.trimmingCharacters(in: .whitespacesAndNewlines)

        // Name Validation
        if name.isEmpty {
            nameError = "Please enter your name."
        } else if name.count < 2 {
            nameError = "Name must contain at least 2 characters."
        } else {
            nameError = nil
        }

        // Mobile Validation
        if mobile.isEmpty {
            mobileError = "Please enter mobile number."
        //}
        //else if mobile.count != 10 ||
                  //  !mobile.hasPrefix({ "6789".contains($0) }) {
            mobileError = "Enter a valid 10-digit mobile number."
        } else {
            mobileError = nil
        }

        // Email Validation (Optional)
        if !email.isEmpty &&
            !email.range(
                of: #"^[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$"#,
                options: .regularExpression
            ).map({ _ in true }).map({ $0 })! {
            emailError = "Please enter a valid email address."
        } else {
            emailError = nil
        }

        // State Validation
        stateError = state.isEmpty
            ? "Please enter state."
            : nil

        // City Validation
        cityError = city.isEmpty
            ? "Please enter city."
            : nil
    }

    // MARK: - Validation Result

    private var isFormValid: Bool {
        nameError == nil &&
        mobileError == nil &&
        emailError == nil &&
        stateError == nil &&
        cityError == nil
    }

    func validateIfNeeded() {
        guard hasAttemptedSubmit else { return }
        validateFields()
    }

    // MARK: - Submit

    func submitInquiry() {

        hasAttemptedSubmit = true

        validateFields()

        guard isFormValid else {
            return
        }

        // Call your API here after successful validation.

        showSuccessAlert = true
    }
}
