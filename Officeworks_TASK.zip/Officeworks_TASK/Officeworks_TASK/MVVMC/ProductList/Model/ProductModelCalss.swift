//
//  ProductModelCalss.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 20/11/26.
//




import Foundation
import SwiftUI

// MARK: - Product Model

struct ProductListElement: Codable, Identifiable {

    let id: Int
    let title: String
    let price: Double
    let description: String
    let category: Category
    let image: String
    let rating: Rating
}

// MARK: - Category

enum Category: String, Codable, CaseIterable, Identifiable {

    case electronics = "electronics"
    case jewelery = "jewelery"
    case menSClothing = "men's clothing"
    case womenSClothing = "women's clothing"

    var id: String {
        rawValue
    }

    var displayName: String {

        switch self {

        case .electronics:
            return "Electronics"

        case .jewelery:
            return "Jewellery"

        case .menSClothing:
            return "Men's Clothing"

        case .womenSClothing:
            return "Women's Clothing"
        }
    }

    var icon: String {

        switch self {

        case .electronics:
            return "laptopcomputer"

        case .jewelery:
            return "sparkles"

        case .menSClothing:
            return "tshirt.fill"

        case .womenSClothing:
            return "handbag.fill"
        }
    }

    var color: Color {

        switch self {

        case .electronics:
            return .gray.opacity(0.18)

        case .jewelery:
            return .yellow.opacity(0.18)

        case .menSClothing:
            return .orange.opacity(0.18)

        case .womenSClothing:
            return .pink.opacity(0.18)
        }
    }
}

// MARK: - Rating

struct Rating: Codable {

    let rate: Double
    let count: Int
}

// MARK: - Typealias

typealias ProductList = [ProductListElement]

