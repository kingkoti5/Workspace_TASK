//
//  ProductListView.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 20/11/26.
//



import SwiftUI

struct ProductListView: View {

    // MARK: - ViewModel

    @StateObject  var viewModel:productViewModel
    @EnvironmentObject var coordinator: AppCoordinator

    @State private var cartCount = 3

    // MARK: - Grid Columns

    private let columns = [

        GridItem(.flexible(), spacing: 14),

        GridItem(.flexible(), spacing: 14)
    ]

    // MARK: - Body

    var body: some View {

        NavigationStack {

            ScrollView(showsIndicators: false) {

                VStack(alignment: .leading, spacing: 24) {

                    // Header

                    headerView

                    // Search

                    searchBar

                    // Categories

                    categoriesView

                    // Products

                    productsView
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 30)
            }
            .background(Color(.systemBackground))
            .toolbar(.hidden, for: .navigationBar)
            .task {

                if viewModel.products.isEmpty {

                    await viewModel.productList()
                }
            }
        }
        .tint(.orange)
    }

    // MARK: - Header

    private var headerView: some View {

        HStack {

            Button(action: {}) {

                Image(systemName: "line.3.horizontal")
                    .font(.system(size: 25, weight: .medium))
                    .foregroundStyle(.primary)
            }

            Spacer()

            Text("E-Commerce")
                .font(.system(size: 28, weight: .bold))

            Spacer()

            Button(action: {}) {

                ZStack(alignment: .topTrailing) {

                    Image(systemName: "cart")
                        .font(.system(size: 25, weight: .medium))
                        .foregroundStyle(.primary)

                    Text("\(cartCount)")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(width: 18, height: 18)
                        .background(.red)
                        .clipShape(Circle())
                        .offset(x: 8, y: -8)
                }
            }
        }
        .padding(.top, 10)
    }

    // MARK: - Search Bar

    private var searchBar: some View {

        HStack(spacing: 12) {

            Image(systemName: "magnifyingglass")
                .font(.system(size: 20))
                .foregroundStyle(.secondary)

            TextField(
                "Search products...",
                text: $viewModel.searchText
            )
            .font(.system(size: 17))
        }
        .padding(16)
        .background(Color(.secondarySystemBackground))
        .clipShape(RoundedRectangle(cornerRadius: 20))
    }

    // MARK: - Categories

    private var categoriesView: some View {

        VStack(alignment: .leading, spacing: 16) {

            sectionTitle("Categories")

            ScrollView(.horizontal, showsIndicators: false) {

                HStack(spacing: 18) {

                    // All Products

                    categoryButton(
                        title: "All",
                        icon: "square.grid.2x2.fill",
                        color: .orange.opacity(0.18),
                        isSelected: viewModel.selectedCategory == nil
                    ) {

                        viewModel.selectCategory(nil)
                    }

                    // API Categories

                    ForEach(Category.allCases) { category in

                        categoryButton(
                            title: category.displayName,
                            icon: category.icon,
                            color: category.color,
                            isSelected: viewModel.selectedCategory == category
                        ) {

                            viewModel.selectCategory(category)
                        }
                    }
                }
            }
        }
    }

    // MARK: - Category Button

    private func categoryButton(
        title: String,
        icon: String,
        color: Color,
        isSelected: Bool,
        action: @escaping () -> Void
    ) -> some View {

        Button(action: action) {

            VStack(spacing: 10) {

                Image(systemName: icon)
                    .font(.system(size: 27))
                    .foregroundStyle(.primary)
                    .frame(width: 76, height: 76)
                    .background(color)
                    .clipShape(Circle())
                    .overlay {

                        Circle()
                            .stroke(
                                isSelected ? Color.orange : Color.clear,
                                lineWidth: 2
                            )
                    }

                Text(title)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(
                        isSelected ? .orange : .primary
                    )
                    .lineLimit(1)
            }
            .frame(width: 90)
        }
        .buttonStyle(.plain)
    }

    // MARK: - Products View

    private var productsView: some View {

        VStack(alignment: .leading, spacing: 16) {

            HStack {

                sectionTitle(
                    viewModel.selectedCategory?.displayName ?? "Featured Products"
                )

                Spacer()

                Button("See All") {
                    
                    
                    

                }
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(.orange)
            }

            // Loading

            if viewModel.isLoading {

                ProgressView("Loading products...")
                    .frame(maxWidth: .infinity)
                    .padding()

            }

            // Error

            else if let error = viewModel.errorMessage {

                VStack(spacing: 12) {

                    Text(error)
                        .foregroundStyle(.red)
                        .multilineTextAlignment(.center)

                    Button("Retry") {

                        Task {

                            await viewModel.productList()
                        }
                    }
                }
                .frame(maxWidth: .infinity)
                .padding()

            }

            // Empty Products

            else if viewModel.filteredProducts.isEmpty {

                ContentUnavailableView(
                    "No Products Found",
                    systemImage: "magnifyingglass",
                    description: Text(
                        "Try another search or category."
                    )
                )

            }

            // Product Grid

            else {

                LazyVGrid(columns: columns, spacing: 22) {

                    ForEach(viewModel.filteredProducts) { product in
                        
                        ProductCard(
                            product: product,

                            addToCart: {
                               
                            },

                            onTap: {
                                coordinator.push(routh: .productDetail(productID: Int(product.id)))

                            }
                        )

                    }
                }
            }
        }
    }

    // MARK: - Section Title

    private func sectionTitle(_ title: String) -> some View {

        Text(title)
            .font(.system(size: 23, weight: .bold))
            .foregroundStyle(.primary)
    }
}



