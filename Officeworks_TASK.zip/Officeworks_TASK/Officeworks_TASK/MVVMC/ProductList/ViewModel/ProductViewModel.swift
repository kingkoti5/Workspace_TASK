//
//  ProductViewModel.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 20/11/26.
//

import Foundation
import Combine
@MainActor
class productViewModel:ObservableObject {
    
    
    @Published var products: [ProductListElement] = []
    @Published var searchText: String = ""
    @Published var selectedCategory: Category? = nil
    @Published var isLoading: Bool = false
    @Published var errorMessage: String? = nil
    let productRepojarity : productListRepojariry
    

    init(productRepojarity: productListRepojariry) {
        self.productRepojarity = productRepojarity
    }
    
    private var toastTask: Task<Void, Never>?

    func productList() async {
        
        
        do {
            let productLiast = try await productRepojarity.priductApicalling()
            
            print("ProductList:::::::::",productLiast)
            products = productLiast
            
        } catch {
            
            
            errorMessage = error.localizedDescription

            ToastManager.shared.showToast(message: error.localizedDescription)
                       print("API Response Failed:", error.localizedDescription)
            
            print("API responce Failed")
            
        }
        
        
    }
    
    
        
    
    // MARK: - Filter Products

    var filteredProducts: [ProductListElement] {

        products.filter { product in

            let matchesCategory: Bool

            if let selectedCategory = selectedCategory {

                matchesCategory = product.category == selectedCategory

            } else {

                matchesCategory = true
            }

            let matchesSearch =
                searchText.isEmpty ||
                product.title.localizedCaseInsensitiveContains(searchText)

            return matchesCategory && matchesSearch
        }
    }

    // MARK: - Select Category

    func selectCategory(_ category: Category?) {
        //print("category:::::::::",category?.icon)
        selectedCategory = category
    }

    // MARK: - Reset Filters

    func resetFilters() {

        selectedCategory = nil
        searchText = ""
    }
 }
    
    
    

// MARK: - Published Properties

//  
//
//   // MARK: - API URL
//
//   private let apiURL = URL(
//       string: "https://fakestoreapi.com/products"
//   )!
//
//   // MARK: - Fetch Products
//
//   func fetchProducts() async {
//
//       isLoading = true
//       errorMessage = nil
//
//       defer {
//           isLoading = false
//       }
//
//       do {
//
//           let (data, response) = try await URLSession.shared.data(
//               from: apiURL
//           )
//
//           guard let httpResponse = response as? HTTPURLResponse,
//                 (200...299).contains(httpResponse.statusCode) else {
//
//               throw URLError(.badServerResponse)
//           }
//
//           let decodedProducts = try JSONDecoder().decode(
//               ProductList.self,
//               from: data
//           )
//
//           products = decodedProducts
//
//       } catch {
//
//           errorMessage = error.localizedDescription
//       }
//   }

  
