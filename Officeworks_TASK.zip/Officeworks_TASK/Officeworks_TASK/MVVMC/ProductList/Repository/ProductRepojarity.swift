//
//  ProductRepojarity.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 20/11/26.
//

import Foundation


class productListRepojariry {
    
    var productServer:ServerApicalling
    
    init(productServer: ServerApicalling) {
        self.productServer = productServer
    }
    
    func priductApicalling() async throws  -> [ProductListElement] {
        
       return try await productServer.apiCalling(url: Apiendpoints.product.url, httpMethod: .GET, modelData: [ProductListElement].self)
        
    }
}
