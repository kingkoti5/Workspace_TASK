//
//  End_BaseURL.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 20/11/26.
//

import Foundation

enum EndPints {
    
    case developement
    
    var baseUrl:String {
        
        switch self {
        case.developement:
            return "https://fakestoreapi.com"

        }
    }
}


struct baseUel {
    
    static var envermenr:EndPints = .developement
    
    static var value: String {
        
        envermenr.baseUrl
    }
    
}


enum Apiendpoints {
    
    case product
    case productDetails(id:Int)
    
    var endpoints:String {
        
        switch self {
            
        case.product:
            
            return "products"
        case.productDetails(let id):
            
            return "products/\(id)"
        
        }
    }
    
    
    var url:URL {
        
        guard let  url = URL(string:endpoints , relativeTo: URL(string: baseUel.value))?.absoluteURL else {
            fatalError("Invalid API URL")
        }
        
        return url
    }
}

