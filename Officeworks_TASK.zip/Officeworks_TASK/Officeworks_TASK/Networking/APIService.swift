//
//  APIService.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 20/11/26.
//

import Foundation

protocol ServerProtocol {

    func apiCalling<T: Codable>(url: URL,httpMethod: httptMethod,modelData: T.Type) async throws -> T
}

class ServerApicalling:ServerProtocol {
    
    func apiCalling<T: Decodable>(url: URL,httpMethod: httptMethod,modelData: T.Type) async throws -> T {

        var urlRequest = URLRequest(url: url)

        urlRequest.httpMethod = httpMethod.rawValue
        urlRequest.timeoutInterval = 30

        let (data, response) = try await URLSession.shared.data(
            for: urlRequest
        )

        guard let httpResponse = response as? HTTPURLResponse else {
            throw APIError.invalidResponse
        }

        guard (200...299).contains(httpResponse.statusCode) else {
            throw APIError.requestFailed(
                statusCode: httpResponse.statusCode
            )
        }

        guard !data.isEmpty else {
            throw APIError.emptyData
        }

        // Decode JSON Response
        do {

            let result = try JSONDecoder().decode(modelData,from: data)

            return result

        } catch {

            throw APIError.decodingFailed(error)
        }
    }

}
    
    
    

