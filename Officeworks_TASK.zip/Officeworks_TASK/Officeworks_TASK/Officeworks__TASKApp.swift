//
//  Officeworks__TASKApp.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 20/11/26.
//

import SwiftUI
import CoreData

@main
struct Officeworks__TASKApp: App {
    let persistenceController = PersistenceController.shared

   
    private let dependencyContainer = AppDependencyContainer()

    
    var body: some Scene {
        WindowGroup {
            
            AppCoardinaterView()
//            AppCoardinaterView()
//            ProductListView(viewModel: dependencyContainer.makePruductViewModel())
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
