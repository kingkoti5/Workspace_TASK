//
//  productInformationSection.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 21/11/26.
//

import SwiftUI

struct productInformationSection: View {
    var productDetails:ProductDetails

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {

            Text(productDetails.title)
                .font(.system(size: 23, weight: .semibold))
                .foregroundStyle(Color(hex: "#333B4B"))

            Text("""
            \(productDetails.description)
            """)
            .font(.system(size: 14))
            .foregroundStyle(Color(hex: "#89909D"))
            .lineSpacing(6)
            .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.horizontal, 25)

    }
}


