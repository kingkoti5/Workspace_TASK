
import SwiftUI

struct ProductCard: View {

    let product: ProductListElement
    let addToCart: () -> Void
    let onTap: () -> Void

    var body: some View {

        VStack(alignment: .leading, spacing: 10) {

            // Product Image
            ZStack(alignment: .topTrailing) {

                AsyncImage(url: URL(string: product.image)) { image in

                    image
                        .resizable()
                        .scaledToFit()
                        .padding(15)

                } placeholder: {

                    ProgressView()
                }
                .frame(height: 170)
                .frame(maxWidth: .infinity)
                .background(Color(.secondarySystemBackground))
                .clipShape(RoundedRectangle(cornerRadius: 20))

                // Rating
                HStack(spacing: 4) {

                    Image(systemName: "star.fill")
                        .foregroundStyle(.yellow)

                    Text(String(format: "%.1f", product.rating.rate))
                        .font(.system(size: 12, weight: .bold))
                }
                .padding(8)
                .background(.white)
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .padding(8)
            }

            // Product Name
            Text(product.title)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(.primary)
                .lineLimit(2)
                .frame(height: 40, alignment: .topLeading)

            // Price and Cart
            HStack {

                Text(String(format: "$%.2f", product.price))
                    .font(.system(size: 18, weight: .bold))

                Spacer()

                Button(action: addToCart) {

                    Image(systemName: "plus")
                        .font(.system(size: 14, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(width: 32, height: 32)
                        .background(Color.orange)
                        .clipShape(Circle())
                }
                .buttonStyle(.plain)
            }
        }
        .contentShape(Rectangle())
        .onTapGesture {
            onTap()
        }
    }
}

//struct ProductCard: View {
//
//    let product: ProductListElement
//
//    let addToCart: () -> Void
//
//    var body: some View {
//
//        VStack(alignment: .leading, spacing: 10) {
//
//            // MARK: Product Image
//
//            ZStack(alignment: .topTrailing) {
//
//                AsyncImage(
//                    url: URL(string: product.image)
//                ) { image in
//
//                    image
//                        .resizable()
//                        .scaledToFit()
//                        .padding(15)
//
//                } placeholder: {
//
//                    ProgressView()
//                }
//                .frame(height: 170)
//                .frame(maxWidth: .infinity)
//                .background(Color(.secondarySystemBackground))
//                .clipShape(
//                    RoundedRectangle(cornerRadius: 20)
//                )
//
//                // MARK: Rating
//
//                HStack(spacing: 4) {
//
//                    Image(systemName: "star.fill")
//                        .foregroundStyle(.yellow)
//
//                    Text(
//                        String(format: "%.1f", product.rating.rate)
//                    )
//                    .font(.system(size: 12, weight: .bold))
//                }
//                .padding(8)
//                .background(.white)
//                .clipShape(RoundedRectangle(cornerRadius: 10))
//                .padding(8)
//            }
//
//            // MARK: Product Name
//
//            Text(product.title)
//                .font(.system(size: 15, weight: .semibold))
//                .foregroundStyle(.primary)
//                .lineLimit(2)
//                .frame(height: 40, alignment: .topLeading)
//
//            // MARK: Price and Cart
//
//            HStack {
//
//                Text(
//                    String(format: "$%.2f", product.price)
//                )
//                .font(.system(size: 18, weight: .bold))
//                .foregroundStyle(.primary)
//
//                Spacer()
//
//                Button(action: addToCart) {
//
//                    Image(systemName: "plus")
//                        .font(.system(size: 14, weight: .bold))
//                        .foregroundStyle(.white)
//                        .frame(width: 32, height: 32)
//                        .background(Color.orange)
//                        .clipShape(Circle())
//                }
//            }
//        }
//    }
//}
