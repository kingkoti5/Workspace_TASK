//
//  RootViewCoardianter.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 21/11/26.
//

import Foundation


final class AppDependencyContainer {
    
    private let productServer = ServerApicalling()

    
    func makePruductViewModel() -> productViewModel {
        
        
        let rePojariryViewModel = productListRepojariry(productServer: productServer)
        let proDuctViewModel = productViewModel(productRepojarity: rePojariryViewModel)
        
        
        return proDuctViewModel
    }
    
    
    func makeProductDetailsViewModel() -> ProductDetailsViewModel {
        
        
        let rePojariryViewModel = productDetailsRepojarity(productServer: productServer)
        let proDuctDetails = ProductDetailsViewModel(productDetails: rePojariryViewModel)
        
        
        return proDuctDetails
    }
    
    
}
