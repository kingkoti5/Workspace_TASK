//
//  PrimaryButton.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 21/11/26.
//


import SwiftUI

struct PrimaryButton: View {

    let title: String
    let action: () -> Void

    var body: some View {

        Button(action: action) {

            Text(title)
                .font(.system(size: 18, weight: .semibold))
                .foregroundColor(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 54)
                .background(AppColors.primaryBrown)
                .clipShape(Capsule())
                .shadow(
                    color: AppColors.primaryBrown.opacity(0.20),
                    radius: 5,
                    x: 0,
                    y: 3
                )
        }
        .buttonStyle(.plain)
    }
}
