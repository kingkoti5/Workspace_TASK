//
//  ReusebuleImageDetails.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 21/11/26.
//

import SwiftUI

struct ReusebuleImageDetails: View {
    
    var productDetails:ProductDetails
    var body: some View {
        ZStack {

            Color(hex: "#D0C9BF")
            
            AsyncImage(url: URL(string: productDetails.image)) { image in

                image

                    .resizable()
                    .scaledToFit()
                    .padding(12)

            } placeholder: {

                ProgressView()
            }

            
        }
        .frame(maxWidth: .infinity)
        .frame(height: 440)
        .clipShape(
            UnevenRoundedRectangle(
                topLeadingRadius: 28,
                bottomLeadingRadius: 28,
                bottomTrailingRadius: 28,
                topTrailingRadius: 28
            )
        )

    }
}

//#Preview {
//    ReusebuleImageDetails()
//}
