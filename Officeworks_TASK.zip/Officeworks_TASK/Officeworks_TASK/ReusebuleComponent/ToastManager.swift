//
//  ToastManager.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 21/11/26.
//


import Foundation
import Combine

@MainActor
final class ToastManager: ObservableObject {

    static let shared = ToastManager()

    @Published var toastMessage: String?
    @Published var isToastVisible: Bool = false

    private var toastTask: Task<Void, Never>?

    private init() {}

    // MARK: - Show Toast

    func showToast(message: String, duration: UInt64 = 3) {

        toastTask?.cancel()

        toastMessage = message
        isToastVisible = true

        toastTask = Task { [weak self] in

            do {
                try await Task.sleep(
                    nanoseconds: duration * 1_000_000_000
                )
            } catch {
                return
            }

            guard let self else { return }

            self.hideToast()
        }
    }

    // MARK: - Hide Toast

    func hideToast() {

        toastTask?.cancel()
        toastTask = nil

        isToastVisible = false
        toastMessage = nil
    }
}


