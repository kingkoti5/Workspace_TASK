//
//  ErrorMessages.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 21/11/26.
//

import Foundation


enum httptMethod:String {
    
    case POST = "POST"
    case GET  = "GET"
}


// MARK: - Custom API Errors

enum APIError: LocalizedError {

    case invalidResponse
    case requestFailed(statusCode: Int)
    case decodingFailed(Error)
    case emptyData

    var errorDescription: String? {

        switch self {

        case .invalidResponse:
            return "Invalid server response."

        case .requestFailed(let statusCode):
            return "API request failed with status code: \(statusCode)"

        case .decodingFailed(let error):
            return "JSON decoding failed: \(error.localizedDescription)"

        case .emptyData:
            return "Server returned empty data."
        }
    }
}
