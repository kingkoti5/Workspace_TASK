//
//  ToastView.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 21/11/26.
//

import SwiftUI


import SwiftUI

struct ToastView: View {

    @ObservedObject var toastManager: ToastManager

    var body: some View {

        if toastManager.isToastVisible,
           let message = toastManager.toastMessage {

            Text(message)
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(.white)
                .padding(.horizontal, 20)
                .padding(.vertical, 12)
                .background(Color.black.opacity(0.85))
                .cornerRadius(10)
                .transition(.move(edge: .bottom).combined(with: .opacity))
                .padding(.bottom, 30)
        }
    }
}



struct ToastModifier: ViewModifier {

    @ObservedObject var toastManager: ToastManager

    func body(content: Content) -> some View {

        content
            .overlay(alignment: .bottom) {
                ToastView(toastManager: toastManager)
                    .animation(.easeInOut, value: toastManager.isToastVisible)
            }
    }
}

extension View {

    func showToast(
        using manager: ToastManager = .shared
    ) -> some View {

        self.modifier(
            ToastModifier(toastManager: manager)
        )
    }
}


//#Preview {
//    ToastView()
//}
