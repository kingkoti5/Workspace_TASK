//
//  CustomTextField.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 21/11/26.
//

import SwiftUI



struct CustomTextField: View {

    let title: String
    let placeholder: String

    @Binding var text: String

    var isRequired: Bool = true
    var keyboardType: UIKeyboardType = .default
    var capitalization: TextInputAutocapitalization = .words
    var errorMessage: String? = nil

    var body: some View {

        VStack(alignment: .leading, spacing: 7) {

            HStack(spacing: 3) {

                Text(title)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(AppColors.textColor)

                if isRequired {
                    Text("*")
                        .foregroundColor(.red)
                }
            }

            TextField(placeholder, text: $text)
                .font(.system(size: 16))
                .foregroundColor(AppColors.textColor)
                .keyboardType(keyboardType)
                .textInputAutocapitalization(capitalization)
                .autocorrectionDisabled()
                .padding(.horizontal, 14)
                .frame(height: 54)
                .background(AppColors.fieldBackground)
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .overlay {
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(
                            errorMessage == nil
                                ? Color.clear
                                : AppColors.errorColor,
                            lineWidth: 1
                        )
                }

            if let error = errorMessage {
                Text(error)
                    .font(.system(size: 12))
                    .foregroundColor(AppColors.errorColor)
            }
        }
    }
}
