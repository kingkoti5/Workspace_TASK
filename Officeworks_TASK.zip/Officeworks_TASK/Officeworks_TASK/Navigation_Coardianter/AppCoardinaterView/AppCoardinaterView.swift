//
//  AppCoardinaterView.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 21/11/26.
//

import SwiftUI
import Combine

struct AppCoardinaterView: View {
    @StateObject private var coordinator = AppCoordinator()
    private let container = AppDependencyContainer()

    
    var body: some View {
        
        NavigationStack(path: $coordinator.path) {
            
            ProductListView(viewModel: container.makePruductViewModel())
            
            
                .navigationDestination(for: AppCoordinator.Route.self) { rout in
                    switch rout {
                    case.productList:
                        
                        ProductListView(
                            viewModel: container.makePruductViewModel()
                        )
                        
                    case.productDetail(productID: let ProductId):
                        
                        ProdudetailsView(viewModel: container.makeProductDetailsViewModel(), productid: ProductId)
                        
                    case.Enquire:
                        EnquireView()
                        
                    }
                }
            
        }
        
        .environmentObject(coordinator)
    }
}

