//
//  AppCoardinater.swift
//  Officeworks­_TASK
//
//  Created by Kotaiah on 21/11/26.
//

import Foundation
import SwiftUI
import Combine


final class AppCoordinator:ObservableObject {
    
    @Published var path = NavigationPath()
    
    
    enum Route: Hashable {
        case productList
        case productDetail(productID: Int)
        case Enquire
    }
    
    func push(routh:Route){
        
        path.append(routh)
        
    }
    
    func Pop() {
        
        if !path.isEmpty {
            path.removeLast()
        }
    }
    
    func popToRoot() {
            path = NavigationPath()
        }
}
